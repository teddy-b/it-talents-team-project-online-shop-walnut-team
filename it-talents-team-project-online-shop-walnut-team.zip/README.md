# IT Talents Team Project - Online Shop - Walnut Team
